
/**
 * Module dependencies.
 */

var express = require('express'),
ObjectId = require('mongoose').Types.ObjectId,
http = require('http'),
path = require('path'),
app = express();

// all environments
app.set('port', process.env.PORT || 3002);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

//Conexión a Mongoose.
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/softSeguros', function(error){
   if(error){
      throw error; 
   }else{
      console.log('Conectado a MongoDB');
   }
});

//Documentos
var ClienteSchema = mongoose.Schema({
	nombreCompleto: String,
    nDocumento: String,
    fechaNacimiento: String,
    email: String
});
var Cliente = mongoose.model('Clientes', ClienteSchema);

app.get('/crm', function(req, res){
	res.sendfile('./public/index.html');
});

app.get('/crm/nuevo-cliente', function(req, res){
	res.sendfile('./public/formulario.html');
});

app.get('/:id([0-9a-fA-F]{24})/editar-cliente', function(req, res){

	console.log(req.params.id);
	Cliente.findOne({_id: ObjectId(req.params.id)}, function(documento, error ){
		
		console.log(documento);
		res.sendfile('./public/formulario.html');
	});

	res.sendfile('./public/formulario.html');
});


app.get('/listar', function(req, res){
	Cliente.find({}, function(error, clientes){
      	if(error){
      		res.send('Error.');
      	}else{
        	res.send(clientes);        	
      	}
   })
});

app.post('/guardar', function(req, res){
	if(req.query._id == null){
		//Inserta
		var cliente = new Cliente({
		   nombreCompleto: req.query.nombreCompleto,
		   nDocumento: req.query.nDocumento,
		   fechaNacimiento: req.query.fechaNacimiento,
		   email: req.query.email
		});
		cliente.save(function(error, documento){
			if(error){
			 	res.send('Error.');
			}else{
			 	res.send(documento);
			}
	   	});
	}
	
});

app.post('/eliminar-cliente', function(req, res){
	console.log("eliminar-cliente");
	
	console.log(req.query);
	
	Cliente.remove({_id: ObjectId(req.query._id)}, function(error){
		if(error){
			res.send('Error.');
		}else{
			res.send('Ok');
		}
   });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
